﻿namespace CheckOutKata
{
    public class Basket
    {
        public string Barcode { get; set; }
        public int Quantity { get; set; }
        public decimal PriceOfItem { get; set; }
    }
}
