﻿using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using Xunit;

namespace CheckOutKata
{
    public class TestClass
    {
        #region Private Attributes 

        private static ObservableCollection<KeyValuePair<string, decimal>> _items;
        private static ObservableCollection<Offers> _offers;
        private static ObservableCollection<Basket> _basket;

        #endregion

        #region Public Attributes 

        public static ObservableCollection<KeyValuePair<string, decimal>> Items => _items;
        public static ObservableCollection<Offers> Offers => _offers;
        public static ObservableCollection<Basket> Basket => _basket;

        #endregion

        [Fact]
        public void CheckDiscountIsApplied()
        {
            _offers = new ObservableCollection<Offers>();
            _offers.Add(new Offers {Barcode = "A99", QuantityRequired = 3, OfferPrice = 1.30m});

            // Change Quantity to Check if offer still applied...
            _basket.Add(new Basket {Barcode = "A99", Quantity = 3, PriceOfItem = 0.50m});


            foreach (var offer in _offers)
            {
                foreach (var item in (_basket.Where(x => x.Barcode == offer.Barcode)))
                {
                    var numberOfDiscountsAchieved = item.Quantity / offer.QuantityRequired;
                    Assert.True(numberOfDiscountsAchieved == 1);
                }
            }
        }
    }
}
