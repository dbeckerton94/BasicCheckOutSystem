﻿namespace CheckOutKata
{
    public class Offers
    {
        public string Barcode { get; set; }
        public int QuantityRequired { get; set; }
        public decimal OfferPrice { get; set; }
    }
}
